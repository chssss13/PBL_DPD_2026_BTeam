# support 폴더의 용도

`v3.5_vivado_template/`는 Vivado 구현을 다시 실행할 때 쓰는 보조 템플릿이다.
v3.8 구현에도 사용했던 v3.5의 동일한 구현 흐름 설정을 보존했다.

| 파일 | 역할 |
|---|---|
| run_vivado.tcl | Vivado 프로젝트·IP 연결과 합성·배치배선 실행 |
| settings.tcl | 대상 장치·언어 등 구현 설정 |
| ResGRU.xdc | 클록 등 타이밍 제약 |
| extraction.tcl | 자원·타이밍 등 결과 보고서 추출 |

`v3/scripts/prepare_shared_impl.py`가 기존 빌드 폴더에서 참조하던 파일들이다.
압축본에서 대용량 빌드 폴더를 제외하면서 이 4개만 따로 보관했다.
기존 스크립트로 재구축하려면 작업 복사본의
`v3/experiments/v3.5/prj_candidate/sol1/impl/verilog/`에 복사한다.

현재 최종 C++ 소스는 `v3/experiments/v3.8/src/`, 검증된 최종 Verilog는
`final_rtl/`에 있다. 결과 문서 열람에는 support 파일을 실행할 필요가 없다.
