# v3_fin_hyeonseo

2026-11-16. **최종 채택본 v3.8**까지의 v3 작업을 정리한 압축본이다. 기존 v3_hyeonseo.zip의 v3 자료 구성을 참고했다.

## 읽는 순서

1. [최종 작업 정리](FINAL_HYEONSEO_SUMMARY.md) — 압축을 풀면 README 옆에 있다.
2. [최종 PPA·검증 결과](v3/results/v3.8/RESULTS.md)
3. [진입부 출력 보관 제거·대기 제어 변경](v3/docs/v3.8_fifo_entry_fusion.md)
4. [최종 LUT·FF breakdown](v3/results/v3.8/AREA_BREAKDOWN.md)
5. [v3 PPA 이력](v3/docs/ppa_history_template.md)
6. [기법·논문 적용 범위](v3/docs/PAPER_CANDIDATES.md)

## 구성

- `v3/experiments/v3.1~v3.8/`: 채택 버전별 소스·테스트벤치·설정·RTL 후처리 및 해시.
- `v3/results/`: C/RTL 출력, 독립 참조·PA 지표, HLS·배치배선 보고서와 상태 기록.
- `v3/docs/`: v3 버전별 변경 설명, 최종 요약, PPA 이력과 breakdown.
- `final_rtl/`: co-simulation 및 실제 구현에 사용한 최종 v3.8 Verilog.
- `v3/src`, `tb`, `golden`, `reference`, `reports`, `baselines`: v3 도입 기준과 비교 근거. 최종 소스는 **`v3/experiments/v3.8/src/`**에 있다.
- `v3/scripts/`: 분석·검증 스크립트.
- `support/v3.5_vivado_template/`: Vivado 구현 실행·설정·클록 제약·보고서 추출 템플릿 4개. 빌드 폴더를 제외하면서 재현 보조 파일만 따로 보관했다. 최종 설계 소스는 아니다. [설명](support/README.md)

v0~v2 폴더, v1/v2 변경 요약·v1 기반 설명, 작업환경 가이드는 제외했다. PA 평가 스크립트가 참조하는 `v2/opendpd_min`과 `v2/tools`도 이번 압축본에서 제외했다. 전체 재실행 시 해당 의존성과 설치 경로 설정은 원래 작업 저장소를 사용한다. 대용량 빌드 프로젝트·캐시·체크포인트는 포함하지 않았다.

루트 `SHA256SUMS.json`은 이 압축본에 실제 포함된 파일 전체의 무결성 목록이다. 하위의 기존 해시 목록은 당시 원본 검증 기록으로 보존했다. 소스·RTL·측정 증거의 바이트는 유지했고, 안내 문서와 PPA 표는 v3 범위에 맞춰 정리했다.
